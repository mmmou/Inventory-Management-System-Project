<?PHP
session_start();

if($_POST['name']|| $_POST['charge']||$_POST['catid']){
 $name= $_POST['name'];
 $charge= $_POST['charge'];
 $categoryid= $_POST['catid'];
 $subid= $_POST['subid'];
	
	
	
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 



$sql= "UPDATE subcategory set name='".$name."',charge='".$charge."',catid='".$categoryid."'  WHERE subid=$subid ";
/* print_r($sql);
exit(); */

if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success"]="service update success";
	header('location:service_list.php');
	
} 
else {
   $_SESSION["error"]="service update not success";
	header('location:service_list.php');
}

$con->close();	

}
	
?>