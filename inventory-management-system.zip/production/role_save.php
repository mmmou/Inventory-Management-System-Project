<?PHP
session_start();

if($_POST['name']|| $_POST['code']){
	$name= $_POST['name'];
	$code= $_POST['code'];
	//echo $_FILES['photo']['name'];
	
		//data insert
	
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 



$sql= "INSERT INTO role (name, code)
VALUES ('$name', '$code')";

if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success"]="Data insert success";
	header('location:create_role.php?$msg='.$msg);
	
} else {
   $_SESSION["error"]="Data insert not success";
	header('location:create_role.php?$msg='.$msg);
}

$con->close();	

}
	
?>