<?php require_once('header.php');?>
        <!-- /top navigation -->

        <!-- page content -->
        <?php require_once('product.php');?>
        
        <!-- /page content -->
        <!-- /footer content -->
<?php require_once('footer.php');?>
       