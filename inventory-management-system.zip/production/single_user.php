 <?php require_once('header.php');

 ?>


         <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Check Your Information</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                   
                    <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
						  <th>Usename</th>
                          <th>Email</th>
                          <th>Photo</th>
                          <th>Edit</th>
                          <th>Remove</th>
                          
                        </tr>
                      </thead>


                      <tbody>
					    <tr>
						  <td><?php echo $_SESSION["user_name"];?></td>
                          <td><?php echo $_SESSION["email"];?></td>
                           <td><img width="25%" height="180px"src="./<?php echo $_SESSION["url"];?>" class="img-rounded" alt="Cinque Terre"></td>
                          <td>  
							<form action="" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
							
							<input type="hidden" id="last-name" name="id" value="<?php echo $row["id"]; ?>" required="required" class="form-control col-md-7 col-xs-12">
							<button type="submit" class="btn btn-success">EDIT</button>
							</form>
						  </td>
						  <td>
							<form action="" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
							<input type="hidden" id="last-name" name="id" value="<?php echo $row["id"]; ?>" required="required" class="form-control col-md-7 col-xs-12">
							
							<button type="submit" class="btn btn-success">Delete</button>
							</form>
						  </td>
                          
                        </tr>
                       
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

        
            </div>
          </div>
        </div>
		<?php require_once('footer.php');?>