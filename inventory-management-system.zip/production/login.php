
<?php 

session_start();

$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=mysqli_connect($servername,$username,$password,$databasename);


if(!empty($_POST['Username'] ||$_POST['password'])){
		$result= mysqli_query($con,"SELECT * FROM USERS WHERE name='".$_POST['Username']."' AND password='".$_POST['password']."'");
	$row=mysqli_fetch_array($result);
	if(is_array($row)){
		$_SESSION["user_name"]=$row["name"];
		$_SESSION["password"]=$row["password"];
		$_SESSION["email"]=$row["email"];
		$_SESSION["url"]=$row["photourl"];
		//$_SESSION['start']=time();
		/* echo $_SESSION["user_name"]; */
		//exit();
		//$_SESSION['expire']=$_SESSION['start']+(.30*60);
	header("location:dashboard.php");
	}
	else{
	header("location:login.html");
}

/* print_r($row);
exit(); */
	
/* 	var_dump($result);
print_r($result);
exit(); */


	}

?>