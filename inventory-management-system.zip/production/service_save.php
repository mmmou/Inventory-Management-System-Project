<?PHP
session_start();

if($_POST['name']|| $_POST['charge']|| $_POST['catid']){
	$name= $_POST['name'];
	$charge= $_POST['charge'];
	$cat_id= $_POST['catid'];
	$catname= $_POST['catname'];
	//$id= $_POST['id'];
	//echo $_FILES['photo']['name'];
	
		//data insert
	
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 



$sql= "INSERT INTO subcategory (name, charge,catid)
VALUES ('$name', '$charge',$cat_id)";

/* var_dump($sql);
exit(); */
if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success"]="Service insert success";
	header('location:create_service.php');
	
} else {
   $_SESSION["error"]="Service insert not success";
	header('location:create_service.php');
}

$con->close();	

}
	
?>