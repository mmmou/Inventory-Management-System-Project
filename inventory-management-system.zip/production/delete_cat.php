<?php

session_start();
	
if(isset($_POST['categoryid'])){ 
 
 
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

// Create connection
$con = new mysqli($servername,$username,$password,$databasename);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

// sql to delete a record
$categoryid=$_POST['categoryid'];
$sql = "DELETE FROM category WHERE categoryid=$categoryid";

if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success"]="category delete success";
	header('location:cat_list.php');
	
} 
else {
   $_SESSION["error"]="category delete not success";
	header('location:cat_list.php');
}

$con->close();	
}
?>
