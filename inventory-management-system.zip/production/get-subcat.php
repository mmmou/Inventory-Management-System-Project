<?php
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);


if(!empty($_POST["categoryid"])) {
	$sql ="SELECT * FROM subcategory WHERE catid = '" . $_POST["categoryid"] . "'";
	$result= $con->query($sql);
?>
	
<?php
	foreach($result as $subcategory) {
?>
	<option value="<?php echo $subcategory["subid"]; ?>"><?php echo $subcategory["name"]; ?></option>
<?php
	}
}
if(!empty($_POST["subid"])) {
	$sql ="SELECT charge FROM subcategory WHERE subid = '" . $_POST["subid"] . "'";
	$result= $con->query($sql);
?>
	
<?php
	foreach($result as $charge) {
?>

	<option value="<?php echo $charge["charge"]; ?>" readonly ><?php echo $charge["charge"]; ?></option >
<?php
	}
}
?>