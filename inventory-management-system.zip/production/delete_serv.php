<?php

session_start();
	
if(isset($_POST['subid'])){ 
 
 
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

// Create connection
$con = new mysqli($servername,$username,$password,$databasename);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

// sql to delete a record
$subid=$_POST['subid'];
$sql = "DELETE FROM subcategory WHERE subid=$subid";

if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success"]="service delete success";
	header('location:service_list.php');
	
} 
else {
   $_SESSION["error"]="service delete not success";
	header('location:service_list.php');
}

$con->close();	
}
?>
