<?PHP
session_start();
if(($_POST['name']|| $_POST['code'])){
	$name= $_POST['name'];
	$code= $_POST['code'];
	//echo $_FILES['photo']['name'];
	$url= get_image();
	// $pass=(rand_string(8));
	
		//data insert
	
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 



$sql= "INSERT INTO PRODUCT (name, code,photourl)
VALUES ('$name', '$code','$url')";

//mail send
/* $to="$email";
$subject="this is a your dashboard login password";
$message="$pass";
$mail = mail($to,$subject,$message);
 */
//mail end
if ($con->query($sql) === TRUE) {
   $_SESSION["record"]= "insert  successfully";
	header('location:product.php');
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}

$con->close();	

}
//for image
	function get_image(){
		 $type=explode(".",$_FILES['photo']['name']);
		 
		 $type=$type[count($type)-1];
		  $url="./product/".uniqid(rand()).".".$type;
	 
	 if(in_array($type,array('JPG','jpg','PNG','png'))){
		 if(is_uploaded_file($_FILES['photo']['tmp_name'])){
			 if(move_uploaded_file($_FILES['photo']['tmp_name'],$url)){
				 return $url;
			 }
		 }
	 }
 
	 else{
		 return "Sorry Extenstion doesn't match";
	 }
	}
	//for password
	// function rand_string( $length ) {

	// $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	// return substr(str_shuffle($chars),0,$length);

	// }


	
	
	
	
	
	
	
?>