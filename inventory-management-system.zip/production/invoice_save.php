<?php

$service=$_POST['category-list'];
$charge=$_POST['charge-list'];

$count=count($service);
$charge=count($charge);
for($i=0;$i<$count&&$charge;$i++){
	
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 




$service=$_POST['category-list'];
$sql = "INSERT INTO invoice (s_name,s_rate) VALUES ('$service[$i]','charge[$i]')";

if ($con->query($sql) === TRUE) {
    //echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}



$con->close();
}


?>