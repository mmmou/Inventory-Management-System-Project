<?PHP
session_start();

if($_POST['name']|| $_POST['code']){
 $name= $_POST['name'];
 $code= $_POST['code'];
 $id= $_POST['id'];
	
	
	
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 



$sql= "UPDATE role set name='".$name."',code='".$code."'  WHERE id=$id ";
/* print_r($sql);
exit(); */

if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success_update"]="Role update success";
	header('location:role_list.php');
	
} 
else {
   $_SESSION["error_update"]="Role update not success";
	header('location:role_list.php');
}

$con->close();	

}
	
?>