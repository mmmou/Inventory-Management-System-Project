

<?php
require_once('header.php');

$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

$sql="SELECT catname,categoryid FROM category ";
$result= $con->query($sql);


?>
<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
<script type="text/javascript">
function getState(val) {
	$.ajax({
	type: "POST",
	url: "get-subcat.php",
	data:'categoryid='+val,
	success: function(data){
		$("#subcategory-list").html(data);
	}
	});
}
function getCharge(val) {
	$.ajax({
	type: "POST",
	url: "get-subcat.php",
	data:'subid='+val,
	success: function(data){
		$("#charge-list").html(data);
	}
	});
}
function selectCategory(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}

</script>

<?php
class Random{
  public static function Numeric($length)
      {
          $chars = "1234567890";
          $clen   = strlen( $chars )-1;
          $id  = '';

          for ($i = 0; $i < $length; $i++) {
                  $id .= $chars[mt_rand(0,$clen)];
          }
          return ($id);
      }

 

  
}


?>
    <!-- page content -->
     <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>
				
				</h3>
              </div>

              <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Invocie <small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form action="" method="" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
						<div class="form-group">
                        <label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name">Invoice number <span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 col-xs-6">
                          <input type="text" id="invoice_number" name="invoice_number" value="<?php echo Random::Numeric(8); ?>" required="required" class="form-control col-md-7 col-xs-12" disabled>
                        </div>
						<label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name">Voucher Date<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 col-xs-6">
					
						<input type="text" id="date" name="date" value="<?php echo  date("d/m/Y");?>" required="required" class="form-control col-md-7 col-xs-12" disabled>
                        </div>
                      </div>
					  <div class="form-group">
                        <label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name">User Name<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 col-xs-6">
					
						<input type="text" id="user_name" name="user_name" value="<?php echo $_SESSION["user_name"];?>" required="required" class="form-control col-md-7 col-xs-12" disabled>
                        </div>
						<label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name">Credit Period<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 col-xs-6">
					
						<input type="text" id="credit" name="credit" value="0" required="required" class="form-control col-md-7 col-xs-12" >
                        </div>
                      </div>
						
						<div class="form-group">
                        <label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name">Service Category <span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 col-xs-6">
							<select name="category" id="category-list" class="form-control" onChange="getState(this.value);">
								<option value="">Select category</option>
								<?php
								foreach($result as $category) {
								?>
								<option value="<?php echo $category["categoryid"]; ?><?php echo $category["catname"]; ?>"><?php echo $category["catname"]; ?></option>
								<?php
								}
								?>
								</select>
						 
						</div>
						 <label class="control-label col-md-2 col-sm-2 col-xs-62" for="last-name">Service Cost<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 col-xs-6">
					
						<input type="text" id="service_cost" name="service_cost" value="1" required="required" class="form-control col-md-7 col-xs-12" >
                        </div>
                      </div>
					  <div class="form-group">
                        <label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name">Service name <span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 col-xs-6">
							<select name="subcategory" id="subcategory-list" class="form-control" onChange="getCharge(this.value);">
								<option value="">Select subcategory</option>
						 </select>
						</div>
						<label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name">Service Measurement<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-4 col-xs-6">
					
						<input type="text" id="service_measure" name="service_measure" value="1" required="required" class="form-control col-md-7 col-xs-12" >
                        </div>
					 </div>
					  <div class="form-group">
                        <label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name">Service Charge <span class="required">*</span>
                        </label>
					   <div class="col-md-4 col-sm-4 col-xs-6">
							<select name="charge" id="charge-list" class="form-control"  style="-webkit-appearance: none;" disabled="true">
								<option value="" >Service Charge</option>
						 </select>
						<!-- <div class="col-md-6 col-sm-6 col-xs-12">
					
						 <input type="text" id="charge-list" name="charge" value="" placeholder="Service Charge"required="required" class="form-control col-md-7 col-xs-12" disabled>
                        
						</div>-->
						</div>
						 <label class="control-label col-md-2 col-sm-2 col-xs-6" for="last-name"> <span class="required"></span>
                        </label>
						
						
						
						</div>
						
                  <!--
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Service Charge <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="charge-list" name="charge" value="" required="required" class="form-control col-md-7 col-xs-12" disabled>
                        </div>
                      </div>-->
				  </form>
                  </div>
                </div>
              </div>
            </div>
			
<div class="col-md-4 col-sm-4 col-xs-6 ">
                          <button type="submit" class="btn btn-success" onclick="addRow('dataTable')" onclick="insert()">Add to Invoice</button>
                        </div>
						<!--<div class="col-md-4 col-sm-4 col-xs-6 ">
                          <button type="submit" class="btn btn-success" onclick="myDeleteFunction()" > Invoice</button>
                        </div>-->
<!--table--->
		<div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Service</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
				  <form action="invoice_save.php" method="POST" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
					
				   <table id="dataTable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
						  <th>Checkbox</th>
						  <th>SL NO</th>
                          <th>Service Name</th>
                          <th>Service Rate</th>
                          <th>Measure</th>
                          <th>Amount</th>
                          
                        </tr>
                      </thead>

                     
                    </table>
					
						<div class="col-md-4 col-sm-4 col-xs-6 ">
                          <button type="submit" class="btn btn-success" > Create Invoice</button>
                        </div>
					</form>
                  </div>
 <SCRIPT language="javascript">
		function addRow(tableID) {

			var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var checkbox = row.insertCell(0);
			var checkbox_element = document.createElement("input");
			checkbox_element.type = "checkbox";
			checkbox_element.name="chkbox[]";
			checkbox.appendChild(checkbox_element);

			var id = row.insertCell(1);
			id.innerHTML = rowCount + 0;

			var s_name = row.insertCell(2);
			var s_name_element = document.createElement("input");
			s_name_element.type = "text";
			s_name_element.value=document.getElementById("category-list").value;
			s_name_element.name = "category-list[]";
			s_name.appendChild(s_name_element);
			
			
			var charge = row.insertCell(3);
			var charge_element = document.createElement("input");
			charge_element.type = "text";
			charge_element.value=document.getElementById("charge-list").value;
			charge_element.name = "charge-list[]";
			charge.appendChild(charge_element);
			
			var service_measure = row.insertCell(4);
			var measure_element = document.createElement("input");
			measure_element.type = "text";
			measure_element.value=document.getElementById("service_measure").value;
			measure_element.name = "service_measure[]";
			service_measure.appendChild(measure_element);
			
			var charge = row.insertCell(5);
			var charge_element = document.createElement("input");
			charge_element.type = "text";
			charge_element.value=document.getElementById("charge-list").value;
			charge_element.name = "charge-list[]";
			charge.appendChild(charge_element);

			
			
			///insert value into input field
			// var category=document.getElementById("category-list").value;
			//cell3.innerHTML = category;	 
			// var charge=document.getElementById("charge-list").value;
			//cell4.innerHTML = charge;	 
			//var service_measure=document.getElementById("service_measure").value;
			//cell5.innerHTML = service_measure;
			// var charge=document.getElementById("charge-list").value;
			//cell6.innerHTML = charge;
			 
		
		}
function myDeleteFunction() {
    document.getElementById("dataTable").deleteRow(1);
}


	</SCRIPT>
        <!-- /page content -->
 <?php require_once('footer.php');?>