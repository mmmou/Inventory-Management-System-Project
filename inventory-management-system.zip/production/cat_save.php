<?PHP
session_start();

if($_POST['catname']|| $_POST['code']){
	$catname= $_POST['catname'];
	$code= $_POST['code'];
	//echo $_FILES['photo']['name'];
	
		//data insert
	
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 



$sql= "INSERT INTO category (catname, code)
VALUES ('$catname', '$code')";

if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success"]="Data insert success";
	header('location:create_cat.php?$msg='.$msg);
	
} else {
   $_SESSION["error"]="Data insert not success";
	header('location:create_cat.php?$msg='.$msg);
}

$con->close();	

}
	
?>