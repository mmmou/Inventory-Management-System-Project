<?PHP
session_start();

if($_POST['catname']|| $_POST['code']){
 $name= $_POST['catname'];
 $code= $_POST['code'];
 $categoryid= $_POST['categoryid'];
	
	
	
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 



$sql= "UPDATE category set catname='".$name."',code='".$code."'  WHERE categoryid=$categoryid ";
/* print_r($sql);
exit(); */

if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success"]="category update success";
	header('location:cat_list.php');
	
} 
else {
   $_SESSION["error"]="category update not success";
	header('location:cat_list.php');
}

$con->close();	

}
	
?>