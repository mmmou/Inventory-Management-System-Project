<?php

session_start();
	
if(isset($_POST['id'])){ 
 
 
$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

// Create connection
$con = new mysqli($servername,$username,$password,$databasename);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
} 

// sql to delete a record
$id=$_POST['id'];
$sql = "DELETE FROM role WHERE id=$id";

if ($con->query($sql) === TRUE) {
	//msg
	$_SESSION["success"]="Role delete success";
	header('location:role_list.php');
	
} 
else {
   $_SESSION["error"]="Role delete not success";
	header('location:role_list.php');
}

$con->close();	
}
?>
