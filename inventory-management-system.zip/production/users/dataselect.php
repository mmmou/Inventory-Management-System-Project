<?php


$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$sql="SELECT name, email,photourl FROM USERS";
$result= $con->query($sql);
//var_dump($result);
if($result->num_rows>0){
while($row=$result->fetch_assoc()){
	echo "name:".$row["name"]."Email:".$row["email"]."Photo:".$row["photourl"]."<br />";
}
}

else{
	echo"aste pari nai";
}
$con->close();







?>