<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Basic Table</h2>
  <p>The .table class adds basic styling (light padding and only horizontal dividers) to a table:</p>            
  <table class="table">
    <thead>
      <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Photo</th>
        <th>Update</th>
      </tr>
    </thead>
	 <tbody>
	<?php


$servername="localhost";
$username="root";
$password="";
$databasename="MY_FIRST_TEST";

$con=new mysqli($servername,$username,$password,$databasename);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$sql="SELECT name, email,photourl FROM USERS";
$result= $con->query($sql);
//var_dump($result);
if($result->num_rows>0){
while($row=$result->fetch_assoc()){
	//echo "name:".$row["name"]."Email:".$row["email"]."Photo:".$row["photourl"]."<br />";
?>
	
   
      <tr>
        <td><?php echo $row["name"]; ?></td>
        <td><?php echo $row["email"];?></td>
        <td><img src="../<?php echo $row["photourl"];?>" class="img-rounded" alt="Cinque Terre" width="20%"></td>
  <td><a href="">update</a></td>
      
   <?php   
	}
}

else{
	echo"aste pari nai";
}
$con->close();


?>
	
    </tr>	
    </tbody>
  </table>
</div>

</body>
</html>
